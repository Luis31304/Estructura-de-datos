package com.mycompany.grupo_3_pfa1;

/**
 * Representa un premio dentro del juego.
 * Contiene la operación, el número de avance y la descripción.
 * 
 * @author Grupo 3
 * @version 1.0.4
 */
public class Premio {
    private String operacion;
    private int numero;
    private String descripcion;

    /**
     * Constructor del premio.
     * @param operacion Tipo de operación (+).
     * @param numero Valor numérico del avance.
     * @param descripcion Descripción del premio.
     */
    public Premio(String operacion, int numero, String descripcion) {
        this.operacion = operacion;
        this.numero = numero;
        this.descripcion = descripcion;
    }

    /** @return Operación del premio. */
    public String getOperacion() { return operacion; }

    /** @return Valor numérico del premio. */
    public int getNumero() { return numero; }

    @Override
    public String toString() {
        return operacion + numero + " → " + descripcion;
    }
}