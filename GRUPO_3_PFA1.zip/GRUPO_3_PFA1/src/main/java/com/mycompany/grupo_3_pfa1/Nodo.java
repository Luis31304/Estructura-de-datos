package com.mycompany.grupo_3_pfa1;

/**
 * Representa un nodo enlazado que almacena un dato y
 * una referencia al siguiente nodo.
 * Se utiliza tanto en la pila como en la cola.
 * 
 * @author Grupo 3
 * @version 1.0.4
 */
public class Nodo {
    Object dato;
    Nodo siguiente;

    /**
     * Constructor del nodo.
     * @param dato Objeto que se almacena en el nodo.
     */
    public Nodo(Object dato) {
        this.dato = dato;
        this.siguiente = null;
    }
}