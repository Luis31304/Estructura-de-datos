package com.mycompany.grupo_3_pfa1;


/**
 * Representa a un jugador dentro del juego de carreras.
 * Cada jugador tiene un nombre y una posición en el tablero.
 * 
 * @author Grupo 3
 * @version 1.0.4
 */
public class Jugador {
    private String nombre;
    private int posicion;

    /**
     * Constructor del jugador.
     * @param nombre Nombre del jugador.
     */
    public Jugador(String nombre) {
        this.nombre = nombre;
        this.posicion = 0;
    }

    /** @return Nombre del jugador. */
    public String getNombre() { return nombre; }

    /** @return Posición actual del jugador. */
    public int getPosicion() { return posicion; }

    /**
     * Asigna una nueva posición al jugador.
     * @param posicion Nueva posición.
     */
    public void setPosicion(int posicion) { this.posicion = posicion; }

    @Override
    public String toString() {
        return "Jugador: " + nombre + " | Posición actual: " + posicion;
    }
}