package com.mycompany.grupo_3_pfa1;

/**
 * Representa un castigo dentro del juego.
 * Contiene la operación, el número de retroceso y la descripción.
 * 
 * @author Grupo 3
 * @version 1.0.4
 */
public class Castigo {
    private String operacion;
    private int numero;
    private String descripcion;

    /**
     * Constructor del castigo.
     * @param operacion Tipo de operación (- o =).
     * @param numero Valor numérico del castigo.
     * @param descripcion Descripción del castigo.
     */
    public Castigo(String operacion, int numero, String descripcion) {
        this.operacion = operacion;
        this.numero = numero;
        this.descripcion = descripcion;
    }

    /** @return Operación del castigo. */
    public String getOperacion() { return operacion; }

    /** @return Valor numérico del castigo. */
    public int getNumero() { return numero; }

    @Override
    public String toString() {
        return operacion + numero + " → " + descripcion;
    }
}