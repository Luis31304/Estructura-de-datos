package com.mycompany.grupo_3_pfa1;

import javax.swing.JOptionPane;

/**
 * Implementa una estructura de datos tipo pila (LIFO),
 * utilizando nodos enlazados dinámicamente.
 * 
 * @author Grupo 3
 * @version 1.0.4
 */
public class Pila {
    private Nodo cima;

    /**
     * Agrega un elemento a la pila.
     * @param dato Objeto a apilar.
     */
    public void apilar(Object dato) {
        Nodo nuevo = new Nodo(dato);
        nuevo.siguiente = cima;
        cima = nuevo;
    }

    /**
     * Elimina y devuelve el elemento en la cima de la pila.
     * @return El objeto desapilado o null si está vacía.
     */
    public Object desapilar() {
        if (estaVacia()) {
            JOptionPane.showMessageDialog(null, "La pila está vacía.");
            return null;
        }
        Object dato = cima.dato;
        cima = cima.siguiente;
        return dato;
    }

    /**
     * Verifica si la pila está vacía.
     * @return true si no hay elementos, false en caso contrario.
     */
    public boolean estaVacia() {
        return cima == null;
    }

    /**
     * Muestra los elementos de la pila mediante una ventana.
     */
    public void listar() {
        if (estaVacia()) {
            JOptionPane.showMessageDialog(null, "No hay elementos en esta pila.");
            return;
        }
        String lista = "";
        Nodo aux = cima;
        while (aux != null) {
            lista += aux.dato.toString() + "\n";
            aux = aux.siguiente;
        }
        JOptionPane.showMessageDialog(null, lista, "Elementos en la pila", JOptionPane.INFORMATION_MESSAGE);
    }
}