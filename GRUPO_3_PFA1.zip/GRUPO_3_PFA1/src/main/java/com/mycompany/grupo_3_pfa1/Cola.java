package com.mycompany.grupo_3_pfa1;


import javax.swing.JOptionPane;

/**
 * Implementa una estructura de datos tipo cola (FIFO),
 * utilizando nodos enlazados dinámicamente.
 * 
 * @author Grupo 3
 * @version 1.0.4
 */
public class Cola {
    private Nodo frente;
    private Nodo fin;

    /**
     * Agrega un elemento al final de la cola.
     * @param dato Objeto a encolar.
     */
    public void encolar(Object dato) {
        Nodo nuevo = new Nodo(dato);
        if (estaVacia()) {
            frente = fin = nuevo;
        } else {
            fin.siguiente = nuevo;
            fin = nuevo;
        }
    }

    /**
     * Elimina y devuelve el primer elemento de la cola.
     * @return El objeto desencolado o null si la cola está vacía.
     */
    public Object desencolar() {
        if (estaVacia()) {
            JOptionPane.showMessageDialog(null, "La cola está vacía.");
            return null;
        }
        Object dato = frente.dato;
        frente = frente.siguiente;
        if (frente == null) fin = null;
        return dato;
    }

    /**
     * Verifica si la cola está vacía.
     * @return true si no hay elementos, false en caso contrario.
     */
    public boolean estaVacia() {
        return frente == null;
    }

    /**
     * Muestra los elementos de la cola mediante una ventana.
     */
    public void listar() {
        if (estaVacia()) {
            JOptionPane.showMessageDialog(null, "Cola vacía.");
            return;
        }
        String lista = "";
        Nodo aux = frente;
        while (aux != null) {
            lista += aux.dato.toString() + "\n";
            aux = aux.siguiente;
        }
        JOptionPane.showMessageDialog(null, lista, "Lista de jugadores", JOptionPane.INFORMATION_MESSAGE);
    }
}
